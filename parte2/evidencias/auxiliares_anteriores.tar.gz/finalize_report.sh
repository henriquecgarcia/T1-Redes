set -e
cd /home/henrique/UNIFESP/RedesT1
python3 - <<'PY'
import csv,json
from pathlib import Path
p=Path('parte2/evidencias/reprodutibilidade/evidencias/piloto.csv')
rows=list(csv.DictReader(p.open()));assert len(rows)==16
assert len({r['round_id'] for r in rows})==4
assert all(r['status']=='ok' and r['sha256_expected']==r['sha256_actual'] for r in rows)
Path('parte2/evidencias/reprodutibilidade/verificacao.json').write_text(json.dumps(dict(rounds=4,observations=16,all_sha256_match=True,status='ok'),indent=2))
PY
python3 parte2/scripts/build_report.py
bash parte2/scripts/review_pdf.sh