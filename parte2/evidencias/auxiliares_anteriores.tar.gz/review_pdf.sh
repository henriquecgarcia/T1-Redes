set -e
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.."
mkdir -p build/qa
pdfinfo relatorio_final.pdf > evidencias/pdfinfo.log
grep -E 'Overfull|Underfull|Warning|undefined' evidencias/latex_compilacao_3.log > evidencias/latex_avisos.log || true
cat evidencias/latex_avisos.log
head -19 evidencias/pdfinfo.log
pdftoppm -scale-to 1050 -png relatorio_final.pdf build/qa/page > evidencias/pdf_render.log 2>&1
python3 - <<'PY'
from pathlib import Path
from PIL import Image,ImageDraw
files=sorted(Path('build/qa').glob('page-*.png'))
for g in range((len(files)+7)//8):
 out=Image.new('RGB',(1200,860),'#ddd')
 for j,p in enumerate(files[g*8:(g+1)*8]):
  im=Image.open(p).convert('RGB');im.thumbnail((280,395));x=(j%4)*300;y=(j//4)*430
  out.paste(im,(x+(300-im.width)//2,y+12));ImageDraw.Draw(out).text((x+10,y+410),p.name,fill='black')
 out.save(f'build/qa/contact-{g}.png')
PY