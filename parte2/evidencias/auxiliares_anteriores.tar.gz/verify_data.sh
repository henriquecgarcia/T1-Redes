set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.."
python3 parte2/scripts/check_outputs.py | tee parte2/evidencias/verificacao_final.log
python3 parte2/scripts/test_analysis.py 2>&1 | tee parte2/evidencias/testes_analise.log
python3 parte2/scripts/plot_topology.py
python3 - <<'PY'
import csv,json
from pathlib import Path
root=Path('parte2');rows=list(csv.DictReader((root/'resultados_resumidos.csv').open()))
for r in rows:
 if r['size_bytes']=='4194304':print(r['network'],r['operation'],r['clients'],r['duration_s_mean'],r['throughput_mbps_mean'],r['aggregate_mbps_mean'])
print((root/'evidencias/analise_integridade.json').read_text())
PY