set -e
cd /home/henrique/UNIFESP/RedesT1
docker exec -i core /opt/core/venv/bin/python - <<'PY' > parte2/evidencias/core_versao.log
import core,importlib.metadata as m
print('module:',core.__file__)
for d in m.distributions():
 if d.metadata['Name'].lower()=='core':print('version:',d.version)
PY
docker exec core sha256sum /tmp/redest1-work/src/client.c /tmp/redest1-work/src/server.c /tmp/redest1-work/src/protocol.h /tmp/redest1-work/build/client /tmp/redest1-work/build/server > parte2/evidencias/fontes_binarios_executados.sha256
python3 parte2/scripts/check_outputs.py > parte2/evidencias/verificacao_final.log
python3 - <<'PY'
import hashlib,subprocess as sp
from pathlib import Path
mapping={'src/client.c':Path('parte1/src/tcp_client.c'),'src/server.c':Path('parte1/src/tcp_server.c'),'src/protocol.h':Path('parte1/src/protocol.h')}
lines=Path('parte2/evidencias/fontes_binarios_executados.sha256').read_text().splitlines()
for relative,p in mapping.items():
 expected=next(line.split()[0] for line in lines if line.endswith('/'+relative))
 assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
print('Final source contents match the source contents used for the full campaign.')
PY
cat parte2/evidencias/core_versao.log
tail -6 parte2/evidencias/repro_execucao.log