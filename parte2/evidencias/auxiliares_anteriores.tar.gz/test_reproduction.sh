set -e
cd /home/henrique/UNIFESP/RedesT1
mkdir -p parte2/evidencias/historico
for file in organizar.sh prepare_repro.sh inspect_tex.sh; do if test -f "parte2/scripts/$file"; then mv "parte2/scripts/$file" parte2/evidencias/historico/; fi; done
if test -f parte1/scripts/run_verify.sh; then mv parte1/scripts/run_verify.sh parte2/evidencias/historico/; fi
CORE_WORKDIR=/tmp/redest1-repro-organizado CORE_EXPORT_DIR=/home/henrique/UNIFESP/RedesT1/parte2/evidencias/reprodutibilidade bash parte2/scripts/run_docker.sh pilot > parte2/evidencias/repro_execucao.log 2>&1
chown -R henrique:henrique parte2/evidencias