cd /home/henrique/UNIFESP/RedesT1/parte2
sed -n '320,342p' relatorio_final.tex
sed -n '806,824p' relatorio_final.tex