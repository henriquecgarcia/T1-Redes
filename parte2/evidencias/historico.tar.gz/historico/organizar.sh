set -e
cd /home/henrique/UNIFESP/RedesT1
mkdir -p parte1/originais parte2/evidencias/historico
if test -d 1_TCPTrasmission; then
 test "$(realpath parte1/originais)" = /home/henrique/UNIFESP/RedesT1/parte1/originais
 mv 1_TCPTrasmission parte1/originais/
fi
mv parte1/src/client.c parte1/src/tcp_client.c
mv parte1/src/server.c parte1/src/tcp_server.c
mv parte1/scripts/generate_matrix.py parte2/scripts/
cp README.md parte2/evidencias/historico/README_antes_organizacao.md
for name in _recover.sh _resume_check.sh; do if test -f "$name"; then mv "$name" parte2/evidencias/historico/; fi; done
{
uname -a
cat /etc/os-release
lscpu
free -h
gcc --version | head -1
docker inspect core --format 'image={{.Image}} privileged={{.HostConfig.Privileged}}'
docker exec core bash -lc '/opt/core/venv/bin/python --version; /tmp/redest1-work/tools/iperf3 --version; cat /etc/os-release'
} > parte2/evidencias/ambiente.log 2>&1
sha256sum parte1/originais/1_TCPTrasmission/client/tcp_client.c parte1/originais/1_TCPTrasmission/server/tcp_server.c > parte1/evidencias/originais_funcionais.sha256