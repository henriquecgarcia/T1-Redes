set -e
cd /home/henrique/UNIFESP/RedesT1
wget -q https://downloads.es.net/pub/iperf/iperf-3.22.tar.gz -O parte2/tools/iperf-3.22.tar.gz
sha256sum parte2/tools/iperf-3.22.tar.gz > parte2/evidencias/iperf_source.sha256
docker exec core mkdir -p /tmp/redest1-work/parte2/core
docker cp parte2/core/run_experiments.py core:/tmp/redest1-work/parte2/core/run_experiments.py
docker exec -e T1_RESULT_ROOT=/tmp/redest1-work -e T1_BINARY_DIR=/tmp/redest1-work/build core /opt/core/venv/bin/python /tmp/redest1-work/parte2/core/run_experiments.py --phase main > parte2/evidencias/retomada_concluida.log
sha256sum parte1/src/*.c parte1/src/*.h parte2/evidencias/codigo_executado/run_experiments.py > parte2/evidencias/fontes_finais.sha256
cat parte2/evidencias/retomada_concluida.log
tail -7 parte1/evidencias/verificacao_execucao.log