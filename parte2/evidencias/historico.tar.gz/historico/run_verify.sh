cd /home/henrique/UNIFESP/RedesT1
bash parte1/scripts/verify.sh > parte1/evidencias/verificacao_execucao.log 2>&1