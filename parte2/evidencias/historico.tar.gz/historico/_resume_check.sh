cd /home/henrique/UNIFESP/RedesT1
tail -4 evidencias/experimentos_execucao.log
docker exec core ps -eo pid,args | grep -E 'run_experiments|build/server|iperf3' | head -12
wc -l resultados_brutos.csv evidencias/rodadas_concluidas.jsonl
ls scripts