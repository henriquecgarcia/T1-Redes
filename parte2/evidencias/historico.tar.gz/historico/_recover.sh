set -e
cd /home/henrique/UNIFESP/RedesT1
mkdir -p parte1/src parte1/scripts parte1/evidencias parte1/build parte2/core parte2/scripts parte2/evidencias parte2/graficos parte2/tools
docker cp core:/tmp/redest1-work/src/. parte1/src/
docker cp core:/tmp/redest1-work/build/. parte1/build/
docker cp core:/tmp/redest1-work/scripts/. parte1/scripts/
docker cp core:/tmp/redest1-work/core/. parte2/core/
docker cp core:/tmp/redest1-work/evidencias/. parte2/evidencias/
docker cp core:/tmp/redest1-work/resultados_brutos.csv parte2/resultados_brutos.csv
docker cp core:/tmp/redest1-work/matriz_experimental.csv parte2/matriz_experimental.csv
docker cp core:/tmp/redest1-work/tools/. parte2/tools/
wc -l parte2/resultados_brutos.csv parte2/evidencias/rodadas_concluidas.jsonl
find parte1 parte2 -maxdepth 2 -type f
cat README.md
git log -3 --oneline
chown -R henrique:henrique parte1 parte2