#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <omp.h>

#define PORT 8080
#define MAX_CLIENTS 8
#define BUFFER_SIZE 4096
#define MAX_LINE 1024
#define MAX_FILE_SIZE (1024ULL * 1024 * 1024)

int connected_clients = 0;

static int send_all(int fd, const void *data, size_t len)
{
    const char *p = data;
    while (len)
    {
        ssize_t n = send(fd, p, len, MSG_NOSIGNAL);
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0)
            return -1;
        p += n;
        len -= (size_t)n;
    }
    return 0;
}

// Reads a single newline-terminated header without swallowing file bytes.
static int read_line(int fd, char *out, size_t cap)
{
    size_t i = 0;
    while (i + 1 < cap)
    {
        char ch;
        ssize_t n = recv(fd, &ch, 1, 0);
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0)
            return -1;
        if (ch == '\n')
        {
            out[i] = '\0';
            return 0;
        }
        if (ch == '\r' || ch == '\0')
            return -1;
        out[i++] = ch;
    }
    return -1;
}

static int valid_name(const char *name)
{
    if (!name[0] || !strcmp(name, ".") || !strcmp(name, ".."))
        return 0;
    for (const unsigned char *p = (const unsigned char *)name; *p; p++)
    {
        if ((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
            (*p >= '0' && *p <= '9') || *p == '_' || *p == '-' || *p == '.')
            continue;
        return 0;
    }
    return 1;
}

static int receive_file(int fd, const char *name, uint64_t size)
{
    FILE *f = fopen(name, "wb");
    if (!f)
    {
        send_all(fd, "ERR cannot-open\n", 16);
        return 0;
    }
    // READY means client can now begin streaming the contents.
    if (send_all(fd, "READY\n", 6) < 0)
    {
        fclose(f);
        unlink(name);
        return -1;
    }
    char buffer[BUFFER_SIZE];
    uint64_t remaining = size;
    while (remaining)
    {
        size_t chunk = remaining < sizeof(buffer) ? (size_t)remaining : sizeof(buffer);
        ssize_t n = recv(fd, buffer, chunk, 0);
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0 || fwrite(buffer, 1, (size_t)n, f) != (size_t)n)
        {
            fclose(f);
            unlink(name);
            return -1;
        }
        remaining -= (size_t)n;
    }
    if (fclose(f) != 0)
    {
        unlink(name);
        send_all(fd, "ERR write\n", 10);
        return 0;
    }
    printf("Received: %s (%" PRIu64 " bytes)\n", name, size);
    return send_all(fd, "OK\n", 3) == 0 ? 0 : -1;
}

static int send_file(int fd, const char *name)
{
    FILE *f = fopen(name, "rb");
    if (!f)
        return send_all(fd, "ERR not-found\n", 14) == 0 ? 0 : -1;
    if (fseeko(f, 0, SEEK_END) != 0)
    {
        fclose(f);
        return -1;
    }
    off_t end = ftello(f);
    if (end < 0 || (uint64_t)end > MAX_FILE_SIZE)
    {
        fclose(f);
        return send_all(fd, "ERR size\n", 9) == 0 ? 0 : -1;
    }
    rewind(f);
    char header[80];
    int n = snprintf(header, sizeof(header), "OK %" PRIu64 "\n", (uint64_t)end);
    if (send_all(fd, header, (size_t)n) < 0)
    {
        fclose(f);
        return -1;
    }
    char buf[BUFFER_SIZE];
    size_t count;
    while ((count = fread(buf, 1, sizeof(buf), f)) > 0)
    {
        if (send_all(fd, buf, count) < 0)
        {
            fclose(f);
            return -1;
        }
    }
    int ok = !ferror(f);
    fclose(f);
    printf("Sent: %s (%jd bytes)\n", name, (intmax_t)end);
    return ok ? 0 : -1;
}

static void handle_client(int fd, struct sockaddr_in addr)
{
    char ip[INET_ADDRSTRLEN];
    inet_ntop(AF_INET, &addr.sin_addr, ip, sizeof(ip));
    printf("Connected: %s:%u (thread %d)\n", ip, ntohs(addr.sin_port), omp_get_thread_num());
    connected_clients++;
    char line[MAX_LINE], command[8], name[256], extra;
    while (read_line(fd, line, sizeof(line)) == 0)
    {
        unsigned long long size = 0;
        if (sscanf(line, "%7s %255s %llu %c", command, name, &size, &extra) == 3 &&
            !strcmp(command, "PUT") && valid_name(name) && size <= MAX_FILE_SIZE)
        {
            if (receive_file(fd, name, size) < 0)
                break;
        }
        else if (sscanf(line, "%7s %255s %c", command, name, &extra) == 2 &&
                 !strcmp(command, "GET") && valid_name(name))
        {
            if (send_file(fd, name) < 0)
                break;
        }
        else
        {
            if (send_all(fd, line, strlen(line)) < 0)
                break;
        }
    }
    close(fd);
    printf("Disconnected: %s:%u\n", ip, ntohs(addr.sin_port));
    connected_clients--;
}

int main(void)
{
    int server = socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0)
    {
        perror("socket");
        return 1;
    }
    int reuse = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    struct sockaddr_in address = {0};
    address.sin_family = AF_INET;
    address.sin_port = htons(PORT);
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    if (bind(server, (struct sockaddr *)&address, sizeof(address)) < 0 ||
        listen(server, MAX_CLIENTS) < 0)
    {
        perror("bind/listen");
        close(server);
        return 1;
    }
    printf("Listening on port %d\n", PORT);
#pragma omp parallel num_threads(MAX_CLIENTS + 1)
    {
#pragma omp single
        {
            while (1)
            {
                struct sockaddr_in peer;
                socklen_t length = sizeof(peer);
                int client = accept(server, (struct sockaddr *)&peer, &length);
                if (client < 0)
                {
                    perror("accept");
                    continue;
                }
                if (connected_clients >= MAX_CLIENTS)
                {
                    printf("Too many clients, rejecting connection\n");
                    send(client, "close", 6, 0);
                    close(client);
                    continue;
                }
#pragma omp task firstprivate(client, peer)
                handle_client(client, peer);
            }
        }
    }
    close(server);
    return 0;
}
