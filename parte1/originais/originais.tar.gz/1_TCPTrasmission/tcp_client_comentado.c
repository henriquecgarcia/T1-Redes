/* Cliente TCP interativo para enviar e baixar arquivos do servidor. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/stat.h>

/* Endereco do servidor e limites usados pelo cliente. */
#define SERVER_IP "127.0.0.1"
#define SERVER_PORT 8080
#define BUFFER_SIZE 1024
#define MAX_FILE_SIZE (1024ULL * 1024ULL * 1024ULL)

/* Envia todos os bytes, tratando envios parciais e interrupcoes do sistema. */
static int send_all(int fd, const void *data, size_t len)
{
    const unsigned char *p = data;
    while (len)
    {
        ssize_t n = send(fd, p, len, MSG_NOSIGNAL);
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0)
            return -1;
        p += n;
        len -= (size_t)n;
    }
    return 0;
}

/* Recebe exatamente len bytes, repetindo recv() quando necessario. */
static int recv_exact(int fd, void *data, size_t len)
{
    unsigned char *p = data;
    while (len)
    {
        ssize_t n = recv(fd, p, len, 0);
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0)
            return -1;
        p += n;
        len -= (size_t)n;
    }
    return 0;
}

/* Le uma linha do protocolo sem consumir os bytes do arquivo que vem depois. */
static int recv_line(int fd, char *out, size_t cap)
{
    size_t pos = 0;
    while (pos + 1 < cap)
    {
        char c;
        ssize_t n = recv(fd, &c, 1, 0);
        if (n < 0 && errno == EINTR)
            continue;
        if (n <= 0)
            return -1;
        if (c == '\n')
        {
            out[pos] = '\0';
            return 0;
        }
        out[pos++] = c;
    }
    return -1;
}

/* Retorna somente o nome final de um caminho, sem os diretorios anteriores. */
static const char *base_name(const char *path)
{
    const char *slash = strrchr(path, '/');
    return slash ? slash + 1 : path;
}

/* Verifica se o nome pode ser enviado pelo protocolo. */
static int valid_name(const char *name)
{
    return name[0] && strcmp(name, ".") && strcmp(name, "..") &&
           !strchr(name, '\\') && !strchr(name, '\n') && !strchr(name, ' ');
}

/* Abre um arquivo local e envia seu nome, tamanho e conteudo ao servidor. */
static int handle_put(int fd, const char *path)
{
    const char *name = base_name(path);
    if (!valid_name(name))
    {
        fprintf(stderr, "Nome de arquivo invalido (sem espacos).\n");
        return 0;
    }
    FILE *file = fopen(path, "rb");
    if (!file)
    {
        perror("fopen");
        return 0;
    }
    /* Confere se o caminho aponta para um arquivo regular dentro do limite. */
    struct stat st;
    if (fstat(fileno(file), &st) != 0 || !S_ISREG(st.st_mode) || st.st_size < 0 ||
        (uint64_t)st.st_size > MAX_FILE_SIZE)
    {
        fprintf(stderr, "Arquivo invalido ou maior que 1 GiB.\n");
        fclose(file);
        return 0;
    }
    uint64_t size = (uint64_t)st.st_size;
    char line[BUFFER_SIZE];
    int n = snprintf(line, sizeof(line), "PUT %s %" PRIu64 "\n", name, size);
    if (n < 0 || (size_t)n >= sizeof(line) || send_all(fd, line, (size_t)n))
    {
        fclose(file);
        return -1;
    }
    /* Aguarda o servidor abrir o arquivo antes de transmitir os dados. */
    if (recv_line(fd, line, sizeof(line)))
    {
        fclose(file);
        return -1;
    }
    if (strcmp(line, "READY"))
    {
        printf("Servidor > %s\n", line);
        fclose(file);
        return 0;
    }
    unsigned char buffer[BUFFER_SIZE];
    uint64_t remaining = size;
    /* Envia o arquivo em blocos ate completar o tamanho informado. */
    while (remaining)
    {
        size_t chunk = remaining < sizeof(buffer) ? (size_t)remaining : sizeof(buffer);
        size_t count = fread(buffer, 1, chunk, file);
        if (count != chunk || send_all(fd, buffer, count))
        {
            perror("PUT: transferencia interrompida");
            fclose(file);
            return -1;
        }
        remaining -= count;
    }
    fclose(file);
    if (recv_line(fd, line, sizeof(line)))
        return -1;
    printf("Servidor > %s\n", line);
    return 0;
}

/* Solicita um arquivo ao servidor e salva a resposta como download_nome. */
static int handle_get(int fd, const char *name)
{
    if (!valid_name(name) || strchr(name, '/'))
    {
        fprintf(stderr, "GET: use somente um nome de arquivo, sem caminho/espacos.\n");
        return 0;
    }
    char line[BUFFER_SIZE];
    int n = snprintf(line, sizeof(line), "GET %s\n", name);
    if (n < 0 || (size_t)n >= sizeof(line) || send_all(fd, line, (size_t)n))
        return -1;
    if (recv_line(fd, line, sizeof(line)))
        return -1;
    if (strncmp(line, "OK ", 3))
    {
        printf("Servidor > %s\n", line);
        return 0;
    }
    /* Converte o tamanho anunciado pelo servidor e valida a resposta. */
    errno = 0;
    char *end;
    unsigned long long parsed = strtoull(line + 3, &end, 10);
    if (errno || *end || end == line + 3 || parsed > MAX_FILE_SIZE)
    {
        fprintf(stderr, "Resposta GET invalida: %s\n", line);
        return -1;
    }
    uint64_t remaining = (uint64_t)parsed;
    char dest[BUFFER_SIZE];
    n = snprintf(dest, sizeof(dest), "download_%s", name);
    if (n < 0 || (size_t)n >= sizeof(dest))
        return -1;
    FILE *file = fopen(dest, "wb");
    if (!file)
    {
        perror("fopen");
        /* Mesmo sem conseguir gravar, consome os bytes para manter o protocolo sincronizado. */
        unsigned char discard[BUFFER_SIZE];
        while (remaining)
        {
            size_t chunk = remaining < sizeof(discard) ? (size_t)remaining : sizeof(discard);
            if (recv_exact(fd, discard, chunk))
                return -1;
            remaining -= chunk;
        }
        return 0;
    }
    unsigned char buffer[BUFFER_SIZE];
    int write_error = 0;
    /* Recebe exatamente o tamanho esperado e grava cada bloco no arquivo local. */
    while (remaining)
    {
        size_t chunk = remaining < sizeof(buffer) ? (size_t)remaining : sizeof(buffer);
        if (recv_exact(fd, buffer, chunk))
        {
            fclose(file);
            unlink(dest);
            return -1;
        }
        if (!write_error && fwrite(buffer, 1, chunk, file) != chunk)
            write_error = 1;
        remaining -= chunk;
    }
    if (fclose(file))
        write_error = 1;
    if (write_error)
    {
        perror("Erro ao salvar download");
        unlink(dest);
    }
    else
    {
        printf("Arquivo salvo em %s (%llu bytes)\n", dest, parsed);
    }
    return 0;
}

/* Exibe os comandos aceitos pelo cliente. */
static void print_help(void)
{
    puts("Comandos: exit, help, clear, GET nome.txt, PUT caminho/arquivo.txt");
}

int main(void)
{
    /* Cria o socket TCP usado para conversar com o servidor. */
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0)
    {
        perror("socket");
        return 1;
    }
    /* Prepara o endereco IPv4 e estabelece a conexao. */
    struct sockaddr_in server = {0};
    server.sin_family = AF_INET;
    server.sin_port = htons(SERVER_PORT);
    if (inet_pton(AF_INET, SERVER_IP, &server.sin_addr) != 1 ||
        connect(sockfd, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
        perror("connect");
        close(sockfd);
        return 1;
    }
    printf("Conectado ao servidor %s:%d\n", SERVER_IP, SERVER_PORT);
    print_help();
    char buffer[BUFFER_SIZE];

    /* Le comandos do usuario e os encaminha ao tratamento correspondente. */
    while (1)
    {
        printf("Voce > ");
        fflush(stdout);
        if (!fgets(buffer, sizeof(buffer), stdin))
            break;
        size_t len = strlen(buffer);
        if (!len)
            continue;
        if (buffer[len - 1] != '\n')
        {
            fprintf(stderr, "Entrada muito longa.\n");
            int c;
            while ((c = getchar()) != '\n' && c != EOF)
            {
            }
            continue;
        }
        buffer[len - 1] = '\0';
        if (!strcmp(buffer, "exit"))
            break;
        if (!strcmp(buffer, "help"))
        {
            print_help();
            continue;
        }
        if (!strcmp(buffer, "clear"))
        {
            printf("\033[2J\033[H");
            continue;
        }
        int result;
        if (!strncmp(buffer, "GET ", 4))
            result = handle_get(sockfd, buffer + 4);
        else if (!strncmp(buffer, "PUT ", 4))
            result = handle_put(sockfd, buffer + 4);
        else
        {
            /* Para outros textos, envia a mensagem e aguarda o echo do servidor. */
            size_t data_len = strlen(buffer);
            buffer[data_len++] = '\n';
            result = send_all(sockfd, buffer, data_len);
            if (!result)
                result = recv_exact(sockfd, buffer, data_len);
            if (!result)
                printf("Servidor > %.*s", (int)data_len, buffer);
        }
        if (result < 0)
        {
            fprintf(stderr, "Conexao interrompida.\n");
            break;
        }
    }
    close(sockfd);
    puts("Conexao encerrada.");
    return 0;
}
